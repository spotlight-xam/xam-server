package spring.server.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import spring.server.entity.User;

public interface UserAuthRepository extends JpaRepository<User, Long> {
}
