//package spring.server.service;
//
//import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.RequestBody;
//import spring.server.entity.dto.login.UserLoginRequest;
//import spring.server.util.JwtUtil;
//
//@Service
//public class UserAuthService {
//
//    public String login( UserLoginRequest userLoginRequest){
//
//        return JwtUtil.createJwt(userLoginRequest.getLoginId());
//    }
//
//}
