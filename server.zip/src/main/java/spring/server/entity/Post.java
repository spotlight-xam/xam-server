package spring.server.entity;

public class Post {
}
