package spring.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaekApplicationTests {

	@Test
	void contextLoads() {
	}

}
